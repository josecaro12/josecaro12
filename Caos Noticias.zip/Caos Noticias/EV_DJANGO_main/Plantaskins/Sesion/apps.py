from django.apps import AppConfig


class SesionConfig(AppConfig):
    name = 'Sesion'
