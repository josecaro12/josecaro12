from django.test import TestCase
from Admin_Noticias.models import Autor, Planta, Noticia


class AutorModelTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        Autor.objects.create(id_autor='59b15a9d-4873-4215-bb1f-e0655799dee4', nom_autor='Diego Dinamarca Abarca')
    
    def test_nom_autor_label(self):
        autor=Autor.objects.get(id_autor='59b15a9d-4873-4215-bb1f-e0655799dee4')
        field_label= autor._meta.get_field('nom_autor').verbose_name
        self.assertEquals(field_label, 'nom autor')

    def test_nom_autor_max_length(self):
        autor=Autor.objects.get(id_autor='59b15a9d-4873-4215-bb1f-e0655799dee4')
        max_length = autor._meta.get_field('nom_autor').max_length
        self.assertEquals(max_length, 25)

    def test_get_absolute_url(self):
        autor=Autor.objects.get(id_autor='59b15a9d-4873-4215-bb1f-e0655799dee4')
        self.assertEquals(autor.get_absolute_url(), '/access/autor/59b15a9d-4873-4215-bb1f-e0655799dee4/')

class PlantaModelTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        Planta.objects.create(id_planta='7e2177b7-5682-4fb1-a4eb-ed1f30edf779', nombre='PS4 PRO', generacion= '8va generación')

    def test_nom_planta_label(self):
        planta=Planta.objects.get(id_planta='7e2177b7-5682-4fb1-a4eb-ed1f30edf779')
        field_label=planta._meta.get_field('nombre').verbose_name
        self.assertEquals(field_label, 'nombre')

    def test_nom_planta_max_length(self):
        planta=Planta.objects.get(id_planta='7e2177b7-5682-4fb1-a4eb-ed1f30edf779')
        max_length= planta._meta.get_field('nombre').max_length
        self.assertEquals(max_length, 50)

    def test_generacion_planta_max_length(self):
        planta=Planta.objects.get(id_planta='7e2177b7-5682-4fb1-a4eb-ed1f30edf779')
        max_length=planta._meta.get_field('generacion').max_length
        self.assertEquals(max_length, 25)


    def test_get_absolute_url(self):
        planta=Planta.objects.get(id_planta='7e2177b7-5682-4fb1-a4eb-ed1f30edf779')
        self.assertEquals(planta.get_absolute_url(),'/access/planta/7e2177b7-5682-4fb1-a4eb-ed1f30edf779/')
