from django.contrib import admin
from . models import Autor, Planta, Formulario, Noticia, AreaPostular, NivelEducacional
# Register your models here.



admin.site.register(Autor)
admin.site.register(Planta)
admin.site.register(Formulario)
admin.site.register(Noticia)
admin.site.register(NivelEducacional)
admin.site.register(AreaPostular)
