from django.apps import AppConfig


class AdminNoticiasConfig(AppConfig):
    name = 'Admin_Noticias'


