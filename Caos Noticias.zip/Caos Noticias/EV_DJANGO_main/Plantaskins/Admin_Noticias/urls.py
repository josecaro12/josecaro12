from django.urls import path
from . import views

urlpatterns = [
    #Path paginas principales
    path('home/', views.index, name='index'),
    path('videogames/', views.videogames, name='videogames'),
    path('plantas/', views.plantas, name='plantas'),
    path('gracias/', views.gracias, name='gracias'),
]

urlpatterns += [
    #Path CRUD Autor
    path('autor/create/', views.AutorCreate.as_view(), name='autor_create'),
    path('autor/<str:pk>/', views.AutorDetailView.as_view(), name='autor_detail'),
    path('autor/<str:pk>/update/', views.AutorUpdate.as_view(), name='autor_update'),
    path('autor/<str:pk>/delete/', views.AutorDelete.as_view(), name='autor_delete'),
    path('autores/', views.AutorListView.as_view(), name='autor_list'),
    #Path CRUD Noticia
    path('noticia/create/', views.NoticiaCreate.as_view(), name='noticia_create'),
    path('noticia/<str:pk>/', views.NoticiaDetailView.as_view(), name='noticia_detail'),
    path('noticia/<str:pk>/update/', views.NoticiaUpdate.as_view(), name='noticia_update'),
    path('noticia/<str:pk>/delete/', views.NoticiaDelete.as_view(), name='noticia_delete'),
    path('noticias/', views.NoticiaListView.as_view(), name='noticia_list'),
    #Path CRUD Planta
    path('planta/create/',views.PlantaCreate.as_view(), name = 'planta_create'),
    path('planta/<str:pk>/',views.PlantaDetailView.as_view(), name = 'planta_detail'),
    path('planta/<str:pk>/update/',views.PlantaUpdate.as_view(), name = 'planta_update'),
    path('planta/<str:pk>/delete/',views.PlantaDelete.as_view(), name = 'planta_delete'),
    path('lista_plantas/', views.PlantaListView.as_view(), name='planta_list'),
    #Crud Formulario
    path('admin_noticias/Formulario/create/', views.formulario_nuevo,name='contacto_create'),
    path('admin_noticias/gracias/<str:pk>', views.FormDetailView.as_view(), name='gracias_detail'),
]