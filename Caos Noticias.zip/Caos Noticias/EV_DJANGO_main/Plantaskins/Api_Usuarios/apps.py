from django.apps import AppConfig


class ApiUsuariosConfig(AppConfig):
    name = 'Api_Usuarios'
